#ifndef SOCK64_INIT_H
#define SOCK64_INIT_H

bool isPremium = false;
char version[69]="com.tencent.ig";
float healthbuff[2],health;

#endif